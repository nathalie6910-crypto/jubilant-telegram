import json
import os
from pathlib import Path
from urllib.request import Request, urlopen

STATE_FILE = Path("state.json")
TOPIC = os.environ.get("NTFY_TOPIC", "").strip()
if not TOPIC:
    raise RuntimeError("Le secret GitHub NTFY_TOPIC n'est pas configuré.")

request = Request(
    "https://lichess.org/api/users/status?ids=ClementiNN",
    headers={"User-Agent": "ClementiNN-online-notifier/1.0"},
)
with urlopen(request, timeout=20) as response:
    players = json.loads(response.read().decode("utf-8"))
player = next((p for p in players if p.get("id", "").lower() == "clementinn"), None)
if player is None:
    raise RuntimeError("Profil introuvable : vérifie le nom du joueur.")

online = bool(player.get("online", False))
previous = None
if STATE_FILE.exists():
    previous = json.loads(STATE_FILE.read_text(encoding="utf-8")).get("online")

if previous is False and online:
    message = "ClementiNN est maintenant en ligne sur Lichess."
    req = Request(
        f"https://ntfy.sh/{TOPIC}",
        data=message.encode("utf-8"),
        headers={"Title": "ClementiNN est en ligne", "Priority": "high"},
        method="POST",
    )
    with urlopen(req, timeout=20) as response:
        if response.status >= 300:
            raise RuntimeError("Échec de l'envoi de la notification.")

STATE_FILE.write_text(json.dumps({"online": online}) + "\n", encoding="utf-8")
print(f"Statut Lichess vérifié : {'en ligne' if online else 'hors ligne'}")

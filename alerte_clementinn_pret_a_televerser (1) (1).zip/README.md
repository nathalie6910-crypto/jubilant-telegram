# Alerte ClementiNN sur Lichess

Le workflow vérifie le statut public de ClementiNN sur Lichess environ toutes les 5 minutes et envoie une notification ntfy lorsqu'il détecte un passage hors ligne → en ligne.

## Installation
1. Installe l'application **ntfy** sur l'iPhone.
2. Abonne-toi dans l'application à un sujet avec un nom long, aléatoire et unique.
3. Dans GitHub, ouvre **Settings → Secrets and variables → Actions → New repository secret**.
4. Nom : `NTFY_TOPIC`. Valeur : le nom exact du sujet ntfy, sans `https://ntfy.sh/`.
5. Ouvre **Actions** et active les workflows si GitHub le demande.
6. Dans **Actions → Surveillance ClementiNN**, clique sur **Run workflow** pour tester.

## Limites
- Surveillance de Lichess uniquement; ce script ne vérifie pas Chess.com.
- GitHub Actions peut démarrer les tâches avec retard; toutes les 5 minutes est une fréquence visée, pas une garantie exacte.
- Les sujets ntfy publics ne sont pas privés : quiconque devine le sujet peut potentiellement lire ou publier des messages. Ne partage pas le nom du sujet.
- La première exécution initialise l'état et n'envoie pas de notification; ensuite, une transition hors ligne → en ligne déclenche une alerte.
